int main(void) {
	char lettre;
	int valeur;
	
	/* ce sont des valeurs comme les autres */
	valeur = 12;
	lettre = 'A'; 
	printf("%d\n", valeur);
	
}
