int main(void) {
	float valeur;
	
	valeur = 12.3;
	printf("%f\n", valeur);
	valeur += 1;
	
	return 0;
}
