#!/bin/bash

last | grep -v "^reboot"  | grep -v "^shutdown" | tr -s ' ' | cut -d' ' -f6 | \
cut -d':' -f1 | grep -v '^$' | cut -b1-2 | sort -n -s -k2,2 | uniq -c | sed \
's/^[[:space:]]\+//' | sort -n -k2,2 > data.tmp

#while read col1 col2; do 
#  echo $col2 $col1 >> data2.txt
#done < data.tmp

#sort -n data2.txt > data.txt

# Generate the gnuplot file
printf "%s\n%s\n%s" "set terminal jpeg" "set output 'graph.jpg'" \
"plot 'data.txt' using 1:2 with boxes title 'Utilisation horaire'" > commands.gp

# Run gnuplot
gnuplot commands.gp
