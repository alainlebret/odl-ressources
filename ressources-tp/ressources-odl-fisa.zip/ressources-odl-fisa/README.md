# Ressources pour les TP ODL FISA

Ce dossier contient les ressources nécessaires aux TP ODL :

- TP n°1 : prise en main du terminal
- TP n°2 : édition avec _Vim_
- TP n°3 : gestion des versions avec _Git_
- TP n°4 : programmation de scripts _shell_
- TP n°5 : mise en oeuvre de _gcc_
- TP n°6 : compilation modulaire avec _make_
- TP n°7 : débogage avec _gdb_
- TP n°8 : tests unitaires avec _MinUnit_
- TP n°9 : bibliothèques statiques et dynamiques

Alain Lebret, ENSICAEN, 2022