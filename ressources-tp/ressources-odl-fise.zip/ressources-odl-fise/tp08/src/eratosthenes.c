#include "eratosthenes.h"

void initialize(int primes[], int n) {
}

void select_multiples(int *primes, int n) {
}

void sieve(int primes[], int n) {
}

void display(int primes[], int n) {
}
